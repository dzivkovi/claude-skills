# REMAX — RE/MAX Real Estate Brand Identity

RE/MAX brand system: red-white-blue color palette, bold sans-serif typography, navy accent, Metropolis headings (Word) / Montserrat headings (Google Docs), Arial body. Derived from the 2025 Brand Evolution: Brand Standards U.S. & Canada supplement.

---

## BRAND Tokens

```javascript
const BRAND = {
  dark:       "232323",   // dark charcoal — softer than pure black, premium feel
  light:      "FFFFFF",   // white — page tone (print-friendly, saves toner)
  midGray:    "8A8780",   // warm gray — captions, metadata, secondary text
  lightGray:  "EDEAE0",   // warm cream-gray — table zebra rows, subtle dividers (originally F0F0F0)
  accent:     "0C2749",   // bridge blue (deep navy) — primary accent
  secondary:  "AA1120",   // bridge red — secondary accent, action items
  tertiary:   "A3D4F2",   // sky blue — tertiary accent, soft highlights
  heading:    "Metropolis", // headings, labels, captions (static TTF — Gotham match)
  body:       "Arial",    // body paragraphs, long-form text
};
```

### Default Contact Info

These are example defaults for the repo maintainer. Replace with your own or override at generation time.

```javascript
const DEFAULTS = {
  name: "Jasmina Zivkovic",
  title: "Sales Representative",
  phone: "647-273-5318",
  email: "info@jasminahomes.ca",
  company: "RE/MAX Your Community Realty Inc."
};
```

### Cover Page Tokens

```javascript
const COVER = {
  barColor: BRAND.secondary,       // red bar at top (RE/MAX signage heritage)
  categoryColor: BRAND.secondary,  // red category text
  categorySpacing: 40,             // 2pt expanded — luxury letter spacing
  categoryCaps: true,              // ALL CAPS category line
  titleSpacing: 40,                // 2pt expanded on main title
};
```

### Why warm neutrals?

The original brand guide pairs its reds and blues with pure black (`#000000`) and cold gray (`#F0F0F0`). Those work for signage and web, but in a printed Word document they read "corporate memo." Dark charcoal (`#232323`) is softer on the eye, and cream-gray (`#EDEAE0`) zebra rows give tables a warm, tactile quality that says "luxury property document" — not "spreadsheet printout." The cream tone (`#F7F5EE`) from the brand guide inspired this warmth.

### Why Bridge colors, not Primary?

RE/MAX Primary Red (`#FF1200`) and Primary Blue (`#0043FF`) are designed for signage and digital screens at high saturation. For printed and Word documents, the Bridge gradations (`#AA1120`, `#0C2749`) provide better readability and a more professional appearance. The brand guide explicitly states these gradations "help create contrast among the Brand Colors."

### Extended palette (for reference, not in BRAND tokens)

| Name | Hex | Use |
| ---- | --- | --- |
| Primary Red | `FF1200` | Signage, high-impact digital |
| Primary Blue | `0043FF` | Signage, high-impact digital |
| Bridge Red | `AA1120` | Document accent bars, callouts |
| Bridge Blue | `0C2749` | Headings, table headers, cover elements |
| Dark Red | `660000` | Hover states, deep emphasis |
| Dark Blue | `000E35` | Deep backgrounds |
| Sky Blue | `A3D4F2` | Soft highlights, tertiary accent |
| Cream | `F7F5EE` | Subtle accents (not used as page bg — white for print) |
| Dark Charcoal | `232323` | Secondary text |
| White | `FFFFFF` | White text on dark backgrounds |

---

## brandStyles

```javascript
const brandStyles = {
  default: {
    document: { run: { font: BRAND.body, size: 22, color: BRAND.dark } }
  },
  paragraphStyles: [
    {
      id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: BRAND.heading, size: 52, bold: true, color: BRAND.accent, characterSpacing: 40 },
      paragraph: {
        spacing: { before: 480, after: 160 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: BRAND.secondary, space: 6 } },
        outlineLevel: 0
      }
    },
    {
      id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: BRAND.heading, size: 36, bold: true, color: BRAND.accent },
      paragraph: { spacing: { before: 360, after: 120 }, outlineLevel: 1 }
    },
    {
      id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
      run: { font: BRAND.heading, size: 22, bold: true, color: BRAND.midGray },
      paragraph: { spacing: { before: 240, after: 80 }, outlineLevel: 2 }
    },
    {
      id: "Caption", name: "Caption", basedOn: "Normal", next: "Normal",
      run: { font: BRAND.heading, size: 16, color: BRAND.midGray, italics: false },
      paragraph: { spacing: { before: 40, after: 160 } }
    },
    {
      id: "Callout", name: "Callout", basedOn: "Normal", next: "Normal",
      run: { font: BRAND.body, size: 22, color: BRAND.dark },
      paragraph: {
        spacing: { before: 120, after: 120 },
        indent: { left: 720 },
        border: { left: { style: BorderStyle.SINGLE, size: 12, color: BRAND.secondary, space: 12 } }
      }
    }
  ]
};
```

### Brand-specific style notes

- **Luxury letter spacing.** H1 uses `characterSpacing: 40` (2pt expanded) — the hallmark of premium real estate typography (think Rolex, Cartier, luxury property brochures). Cover page typography is controlled by the `COVER` tokens above.
- H1 uses navy heading with a **red** bottom border (not accent) — the two-color interplay is core to RE/MAX identity
- Callout blocks use red left border (secondary) to echo the "action bar" pattern from RE/MAX signage
- H2 uses navy (accent) without a border — cleaner hierarchy
- H3 uses warm gray — third level fades to neutral, reducing visual weight

---

## Numbering Config

```javascript
numbering: {
  config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022",
        alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } },
        run: { font: BRAND.body, color: BRAND.secondary } } }] },
    { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.",
        alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] }
  ]
}
```

---

## Design Principles

- **Confident, not loud.** Navy headers on warm cream-gray feel authoritative without shouting. Let the content command attention — the brand stays understated and professional.
- **Red is for action.** Use Bridge Red only for callout labels, accent bars, and emphasis elements. One or two red elements per page maximum. Red on red backgrounds is never permitted.
- **One sans-serif family.** Montserrat for structure, Arial for reading. Both are clean sans-serifs that pair naturally. Never use serif fonts in RE/MAX documents.
- **White space first.** Generous `spacing.before` and `spacing.after` on every element. Never crowd content. The brand guide emphasizes clean, uncluttered layouts.
- **Dense tables, airy prose.** Use 9.5pt Arial (size 19) for table data cells — tighter than body text, giving tables professional financial-document density. Body prose stays at 11pt.
- **Tonal color.** Navy (accent) for authority and structure, red (secondary) for action and emphasis, sky blue (tertiary) for positive findings or soft highlights. This is a creative judgment — adapt the palette to the document's emotional context.

---

## Color Reference

| Role | Hex | Use |
| ---- | --- | --- |
| Dark | `232323` | All body text, strong backgrounds (dark charcoal, not pure black) |
| Light | `FFFFFF` | Page tone, white background (print-friendly) |
| Mid Gray | `8A8780` | Captions, metadata, subdued text |
| Light Gray | `EDEAE0` | Table zebra rows, subtle dividers (warm cream-gray, originally `F0F0F0`) |
| **Accent** | `0C2749` | H1/H2 headings, table headers, cover elements |
| **Secondary** | `AA1120` | Action bars, callout labels, bullet accents |
| Tertiary | `A3D4F2` | Soft highlights, info boxes |
| Accent tint | `F0F2F8` | Faint navy background for emphasis callouts |
| Warm tint | `FBF9F4` | Faint cream background for subtle section highlights |
| Alert tint | `FDF5F5` | Faint red background for caution/action callouts |
| Success tint | `F0F5FB` | Faint sky blue background for positive callouts |

## Typography Reference

| Element | Font | Fallback | Size (pt) | docx units | Special |
| ------- | ---- | -------- | --------- | ---------- | ------- |
| Cover title | Metropolis Bold | Arial Bold | 36 | 72 | +2pt spacing (`characterSpacing: 40`) |
| Cover category | Metropolis Bold | Arial Bold | 22 | 44 | +2pt spacing, `allCaps: true` |
| H1 | Metropolis Bold | Arial Bold | 26 | 52 | +2pt spacing (`characterSpacing: 40`) |
| H2 | Metropolis Bold | Arial Bold | 18 | 36 | |
| H3 | Metropolis Bold | Arial Bold | 11 | 22 | |
| Body | Arial | Calibri | 11 | 22 | |
| Table data | Arial | Calibri | 9.5 | 19 | |
| Table header | Metropolis Bold | Arial Bold | 9 | 18 | |
| Label | Metropolis | Arial | 8.5 | 17 | |
| Caption | Metropolis | Arial | 9 | 18 | |
| Fine print | Arial Italic | Calibri | 7.5 | 15 | |
| Footer | Metropolis | Arial | 8 | 16 | |

---

## Spacing Rhythm

Use multiples of 120 DXA (~1/12 inch):

- Tight: 80 before, 80 after
- Normal: 120 before, 120 after
- Loose (after headings): 160 after
- Section gap: 360-480 before major headings

---

## Document Archetypes

**Market Report / Listing Presentation** — Cover page with large navy title + red accent top bar + subtitle + date. H1 per section (navy, red bottom border), H2 per topic. Arial 11pt body. Callouts with left red border for key statistics.

**Property Brief / CMA** — No cover page. Title is first H1. Header with document title + page number. 2-3 levels max. Data-heavy with branded tables.

**Agent Marketing Flyer** — Bold cover treatment. Large headings, minimal body text. Red accent bars for calls-to-action.

---

## Common Mistakes

- Using Primary Red/Blue instead of Bridge colors in documents (too vivid for print)
- Using Gotham without a license (use Montserrat instead — it's free and 85% match)
- Mixing serif fonts into RE/MAX documents (brand is strictly sans-serif)
- Using red for body text or large text blocks (red is for accents only)
- Overcrowding — RE/MAX brand emphasizes clean, spacious layouts
- Using the REMAX logotype as text (always use the official logo image, never type "REMAX" as styled text)

---

## Logo

**File:** `brands/remax-logo.png` (bundled, 400x245px, transparent background)

The logo is optional — use it alongside agent signature blocks. Typical placement: end of document or cover page, logo to the left of contact lines.

```javascript
// Signature block: logo left, contact info right (borderless table)
function signatureWithLogo(name, title, phone, email) {
  const logoData = fs.readFileSync(path.join(__dirname, "brands", "remax-logo.png"));
  const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
  const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

  const contactLines = [
    new Paragraph({
      spacing: { before: 0, after: 40 },
      children: [new TextRun({ text: name, font: BRAND.heading, size: 22, bold: true, color: BRAND.dark })]
    }),
    title ? new Paragraph({
      spacing: { before: 0, after: 40 },
      children: [new TextRun({ text: title, font: BRAND.body, size: 20, color: BRAND.midGray })]
    }) : null,
    new Paragraph({
      spacing: { before: 0, after: 40 },
      children: [new TextRun({ text: phone, font: BRAND.body, size: 20, color: BRAND.dark })]
    }),
    email ? new Paragraph({
      spacing: { before: 0, after: 0 },
      children: [new ExternalHyperlink({
        children: [new TextRun({ text: email, style: "Hyperlink", font: BRAND.body, size: 20 })],
        link: `mailto:${email}`
      })]
    }) : null,
  ].filter(Boolean);

  return new Table({
    width: { size: 5000, type: WidthType.DXA },
    columnWidths: [1800, 3200],
    rows: [new TableRow({
      children: [
        new TableCell({
          borders: noBorders, width: { size: 1800, type: WidthType.DXA },
          verticalAlign: VerticalAlign.CENTER,
          children: [new Paragraph({
            children: [new ImageRun({
              type: "png", data: logoData,
              transformation: { width: 120, height: 74 },
              altText: { title: "REMAX Logo", description: "REMAX Your Community Realty", name: "remax-logo" }
            })]
          })]
        }),
        new TableCell({
          borders: noBorders, width: { size: 3200, type: WidthType.DXA },
          verticalAlign: VerticalAlign.CENTER,
          children: contactLines
        })
      ]
    })]
  });
}
```

All sizes are starting points — the user can resize the logo and adjust column widths directly in Word.

---

## Print Tips

For luxury printouts that match the digital warmth of this brand:

- **Keep page background WHITE in Word.** Never set a cream page color — the printer will spray a fine toner dusting across every page, tripling cost and making paper feel wavy.
- **Buy the color instead.** Use 28-32lb (105-120gsm) "Natural White" or "Cream" paper (e.g., Hammermill Premium, Mohawk Superfine). The physical paper provides the luxury warmth; the digital document stays clean.
- **The combination:** White background in Word + cream heavyweight paper = the Bridge Blue and Bridge Red pop beautifully, and the document feels substantial in a client's hands.

---

## Font Requirements

This brand requires **Metropolis** (headings, Word workflow) or **Montserrat** (headings, Google Docs workflow), and **Arial** (body).

### Dual-Platform Rule

- **Word workflow:** Use **Metropolis** (static TTFs). Metropolis is a free open-source Gotham match with tighter letterforms than Montserrat. Because it's installed as static .ttf files (one per weight), it completely bypasses the MS Word variable font PDF export bug. PDFs embed Bold weight correctly every time.
- **Google Docs workflow:** Use **Montserrat**. Google's cloud PDF engine handles variable fonts perfectly, and Montserrat is available in the Google Docs font picker. Google Docs cannot load local custom fonts like Metropolis.

The `heading` token defaults to `"Metropolis"` for Word workflows. To generate for Google Docs, change the token to `"Montserrat"`.

### Installation

**Metropolis** (Word — default):

- Download from [GitHub](https://github.com/chrismsimpson/Metropolis), extract, install the static .ttf files (Regular, Bold, Italic, BoldItalic). Right-click > "Install for all users" on Windows. Restart Word.

**Montserrat** (Google Docs):

- Already available in the Google Docs font picker — just select "Montserrat".
- For local preview in Word: download from [Google Fonts](https://fonts.google.com/specimen/Montserrat). Install ONLY the static .ttf files from the `static/` folder (Regular, Bold, Italic, BoldItalic) — do NOT install the variable font files, as they cause Word's PDF export to pick the wrong weight. This is the general variable-font trap described in [`references/font-fidelity.md`](../references/font-fidelity.md); the doctrine there covers instancing static cuts and embedding for any brand.

**Arial** (body): Built into Windows, macOS, and most Linux distributions. No installation needed.

If Metropolis is missing, Word silently falls back to Arial. The document opens fine but headings lose their distinctive character. If you have a Gotham license, change the `heading` token to `"Gotham"` for an exact brand match.
